function calcCheckSum(gstin) {
	var GSTN_CODEPOINT_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', factor = 2, sum = checkCodePoint = 0;
	mod = GSTN_CODEPOINT_CHARS.length, i;
	for (i = gstin.length - 2; i >= 0; i--) {
		var codePoint = -1;
		for (var j = 0; j < GSTN_CODEPOINT_CHARS.length; j++) {
			if (GSTN_CODEPOINT_CHARS[j] == gstin[i]) { codePoint = j; }
		}
		var digit = factor * codePoint; factor = (factor == 2) ? 1 : 2;
		digit = Math.floor(digit / mod) + (digit % mod); sum += digit;
	}
	checkCodePoint = (mod - (sum % mod)) % mod;
	return GSTN_CODEPOINT_CHARS[checkCodePoint];
}
function validatePattern(gstin) {
	var gstinRegexPattern = /^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$/;
	return gstinRegexPattern.test(gstin);
}

function isValidGSTNumber(gstin) {
	gstin = gstin.toUpperCase();
	if (gstin.length != 15) {
		return false;
	}
	return validatePattern(gstin);
} 

function isValidVehicleNumber(vehicleNum) {
	var pattern = /(([A-Za-z]){2,3}(|-)(?:[0-9]){1,2}(|-)(?:[A-Za-z]){2}(|-)([0-9]){1,4})|(([A-Za-z]){2,3}(|-)([0-9]){1,4})/g;
	return pattern.test(vehicleNum);
}